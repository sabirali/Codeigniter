<?php

$string = "<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class " . $c . " extends MY_CController
{
	function __construct()
    {
        parent::__construct();
        \$this->load->model('admin/$m');
		checkAdminLogin();
		\$this->pageTitle = '$c Management';
		\$this->heading = '$c Management';
		\$this->breadcrumbs[] = array('title'=>'Home','link'=>getParam('admin_url'));
	}";

if ($jenis_tabel == 'reguler_table') {
    
$string .= "\n\n    public function index()
    {
        \$q = urldecode(\$this->input->get('q', TRUE));
        \$start = intval(\$this->input->get('start'));
		\$order['orderBy'] = urldecode(\$this->input->get('sO', TRUE)); ##sortOrder column name
		\$order['orderType'] = urldecode(\$this->input->get('sT', TRUE)); ##sort Type

		if(isset(\$_POST['fieldName']) && \$this->input->post('fieldName') != '')
			\$order['orderBy'] = \$this->input->post('fieldName');
		if(isset(\$_POST['orderType']) && \$this->input->post('orderType') != '')
			\$order['orderType'] = \$this->input->post('orderType');
        
        if (\$q <> '') {
            \$config['base_url'] = current_url().'?q=' . urlencode(\$q);
            \$config['first_url'] = current_url().'?q=' . urlencode(\$q);
        } else {
            \$config['base_url'] = current_url();
            \$config['first_url'] = current_url();
        }

        \$config['per_page'] = 10;
        \$config['page_query_string'] = TRUE;
        \$config['total_rows'] = \$this->" . $m . "->total_rows(\$q);
        \$$c_url = \$this->" . $m . "->get_limit_data(\$config['per_page'], \$start, \$q,\$order);

        \$this->load->library('pagination');
        \$this->pagination->initialize(\$config);

        \$data = array(
            '" . $c_url . "_data' => \$$c_url,
            'q' => \$q,
            'pagination' => \$this->pagination->create_links(),
            'total_rows' => \$config['total_rows'],
            'start' => \$start,
        );
		\$data['view']='".$v_list."';
		\$this->heading = 'Manage $c';
		\$this->load->view('admin/content', \$data);
    }";

} else {
    
$string .="\n\n    public function index()
    {
        \$$c_url = \$this->" . $m . "->get_all();

        \$data = array(
            '" . $c_url . "_data' => \$$c_url
        );

        //\$cName=strtolower('$c');
        //\$this->load->view('admin/'.\$cName.'/$v_list', \$data);
		\$data['view']='".$v_list."';
		\$this->heading = 'Manage $c';
		\$this->load->view('admin/content', \$data);
    }";

}
    
$string .= "\n\n    public function read(\$id) 
    {
        \$row = \$this->" . $m . "->get_by_id(\$id);
        if (\$row) {
            \$data = array(";
foreach ($all as $row) {
    $string .= "\n\t\t'" . $row['column_name'] . "' => \$row->" . $row['column_name'] . ",";
}
$string .= "\n\t    );
		\$this->heading = '$c Details';
		\$this->headingIcon = 'fa-hashtag';
        \$data['view']='".$v_read."';
		\$this->load->view('admin/content', \$data);
        } else {
            \$flash_arr = array('flash_type' => 'error',
                'flash_msg' => 'Record Not Found'
            );
            \$this->session->set_flashdata(\$flash_arr);
            redirect(site_url('admin/$c_url'));
        }
    }

    public function create() 
    {
        \$data = array(
            'button' => 'Create',
            'action' => site_url('admin/$c_url/create_action'),";
foreach ($all as $row) {
    $string .= "\n\t    '" . $row['column_name'] . "' => set_value('" . $row['column_name'] . "'),";
}
$string .= "\n\t);
        \$data['view']='".$v_form."';
		\$this->heading = 'Add $c';
		\$this->headingIcon = 'fa-plus-square';
		if (\$this->form_validation->run() == FALSE)
                \$data['error_msg'] = validation_errors();
		\$this->load->view('admin/content', \$data);
    }
    
    public function create_action() 
    {
        \$this->_rules();

        if (\$this->form_validation->run() == FALSE) {
            \$this->create();
        } else {
			\$post = \$this->input->post();
            \$data = array(";
foreach ($non_pk as $row) {
    $string .= "\n\t\t'" . $row['column_name'] . "' => \$this->input->post('" . $row['column_name'] . "',TRUE),";
}
$string .= "\n\t    );

            \$this->".$m."->insert(\$data);
            \$flash_arr = array('flash_type' => 'success',
                'flash_msg' => 'New Record Inserted Successfully'
            );
            \$this->session->set_flashdata(\$flash_arr);
            redirect(site_url('admin/$c_url'));
        }
    }
    
    public function update(\$id) 
    {
        \$row = \$this->".$m."->get_by_id(\$id);

        if (\$row) {
            \$data = array(
                'button' => 'Update',
                'action' => site_url('admin/$c_url/update_action'),";
foreach ($all as $row) {
    $string .= "\n\t\t'" . $row['column_name'] . "' => set_value('" . $row['column_name'] . "', \$row->". $row['column_name']."),";
}
$string .= "\n\t    );
        \$data['view']='".$v_form."';
		\$this->heading = 'Update $c';
		\$this->headingIcon = 'fa-pencil';
		if (\$this->form_validation->run() == FALSE)
            \$data['error_msg'] = validation_errors();
		\$this->load->view('admin/content', \$data);
        } else {
            \$flash_arr = array('flash_type' => 'error',
                'flash_msg' => 'Record Not Found'
            );
            \$this->session->set_flashdata(\$flash_arr);
            redirect(site_url('admin/$c_url'));
        }
    }
    
    public function update_action() 
    {
        \$this->_rules();

        if (\$this->form_validation->run() == FALSE) {
            \$this->update(\$this->input->post('$pk', TRUE));
        } else {
			\$post = \$this->input->post();
            \$data = array(";
foreach ($non_pk as $row) {
    $string .= "\n\t\t'" . $row['column_name'] . "' => \$this->input->post('" . $row['column_name'] . "',TRUE),";
}    
$string .= "\n\t    );

            \$this->".$m."->update(\$this->input->post('$pk', TRUE), \$data);
            \$flash_arr = array('flash_type' => 'success',
                'flash_msg' => 'Record Updated Successfully'
            );
            \$this->session->set_flashdata(\$flash_arr);
            
            redirect(site_url('admin/$c_url'));
        }
    }
    
    public function delete(\$id) 
    {
        \$row = \$this->".$m."->get_by_id(\$id);

        if (\$row) {
            \$this->".$m."->delete(\$id);
            
            \$flash_arr = array('flash_type' => 'success',
                'flash_msg' => 'Record Deleted Successfully'
            );
            \$this->session->set_flashdata(\$flash_arr);
            redirect(site_url('admin/$c_url'));
        } else {
            \$flash_arr = array('flash_type' => 'error',
                'flash_msg' => 'Record Not Found'
            );
            \$this->session->set_flashdata(\$flash_arr);
            redirect(site_url('admin/$c_url'));
        }
    }

    public function _rules() 
    {";
foreach ($non_pk as $row) {
    $int = $row3['data_type'] == 'int' || $row['data_type'] == 'double' || $row['data_type'] == 'decimal' ? '|numeric' : '';
    $string .= "\n\t\$this->form_validation->set_rules('".$row['column_name']."', '".  strtolower(label($row['column_name']))."', 'trim|required$int');";
}    
$string .= "\n\n\t\$this->form_validation->set_rules('$pk', '$pk', 'trim');";
$string .= "\n\t\$this->form_validation->set_error_delimiters('<span class=\"text-danger\">', '</span>');
    }";

if ($export_excel == '1') {
    $string .= "\n\n    public function excel()
    {
        \$this->load->helper('exportexcel');
        \$namaFile = \"$table_name.xls\";
        \$judul = \"$table_name\";
        \$tablehead = 0;
        \$tablebody = 1;
        \$nourut = 1;
        //penulisan header
        header(\"Pragma: public\");
        header(\"Expires: 0\");
        header(\"Cache-Control: must-revalidate, post-check=0,pre-check=0\");
        header(\"Content-Type: application/force-download\");
        header(\"Content-Type: application/octet-stream\");
        header(\"Content-Type: application/download\");
        header(\"Content-Disposition: attachment;filename=\" . \$namaFile . \"\");
        header(\"Content-Transfer-Encoding: binary \");

        xlsBOF();

        \$kolomhead = 0;
        xlsWriteLabel(\$tablehead, \$kolomhead++, \"No\");";
foreach ($non_pk as $row) {
        $column_name = label($row['column_name']);
        $string .= "\n\txlsWriteLabel(\$tablehead, \$kolomhead++, \"$column_name\");";
}
$string .= "\n\n\tforeach (\$this->" . $m . "->get_all() as \$data) {
            \$kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber(\$tablebody, \$kolombody++, \$nourut);";
foreach ($non_pk as $row) {
        $column_name = $row['column_name'];
        $xlsWrite = $row['data_type'] == 'int' || $row['data_type'] == 'double' || $row['data_type'] == 'decimal' ? 'xlsWriteNumber' : 'xlsWriteLabel';
        $string .= "\n\t    " . $xlsWrite . "(\$tablebody, \$kolombody++, \$data->$column_name);";
}
$string .= "\n\n\t    \$tablebody++;
            \$nourut++;
        }

        xlsEOF();
        exit();
    }";
}

if ($export_word == '1') {
    $string .= "\n\n    public function word()
    {
        header(\"Content-type: application/vnd.ms-word\");
        header(\"Content-Disposition: attachment;Filename=$table_name.doc\");

        \$data = array(
            '" . $table_name . "_data' => \$this->" . $m . "->get_all(),
            'start' => 0
        );
        \$this->load->view('admin/" . strtolower($c).'/'.$v_doc . "',\$data);
    }";
}

if ($export_pdf == '1') {
    $string .= "\n\n    function pdf()
    {
        \$data = array(
            '" . $table_name . "_data' => \$this->" . $m . "->get_all(),
            'start' => 0
        );
        
        ini_set('memory_limit', '32M');
        \$html = \$this->load->view('admin/".strtolower($c).'/'.$v_pdf . "', \$data, true);
        \$this->load->library('pdf');
        \$pdf = \$this->pdf->load();
        \$pdf->WriteHTML(\$html);
        \$pdf->Output('" . $table_name . ".pdf', 'D'); 
    }";
}

$string .= "\n\n}\n\n/* End of file $c_file */
/* Location: ./application/controllers/$c_file */";
$hasil_controller = createFile($string, $target . "controllers/admin/" . $c_file);

?>