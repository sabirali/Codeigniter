<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
equire(APPPATH.'/libraries/REST_Controller.php');
class Login extends REST_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('News_model');
        $this->load->library('form_validation');
    }

    public function index_post()
    { die;
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'news/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'news/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'news/index.html';
            $config['first_url'] = base_url() . 'news/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->News_model->total_rows($q);
        $news = $this->News_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'news_data' => $news,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );
        $this->load->view('news/news_list', $data);
    }

    public function read($id) 
    {
        $row = $this->News_model->get_by_id($id);
        if ($row) {
            $data = array(
		'news_id' => $row->news_id,
		'title' => $row->title,
		'summery' => $row->summery,
		'description' => $row->description,
		'image' => $row->image,
		'publish_date' => $row->publish_date,
		'expired_date' => $row->expired_date,
	    );
            $this->load->view('news/news_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('news'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('news/create_action'),
	    'news_id' => set_value('news_id'),
	    'title' => set_value('title'),
	    'summery' => set_value('summery'),
	    'description' => set_value('description'),
	    'image' => set_value('image'),
	    'publish_date' => set_value('publish_date'),
	    'expired_date' => set_value('expired_date'),
	);
        $this->load->view('news/news_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'title' => $this->input->post('title',TRUE),
		'summery' => $this->input->post('summery',TRUE),
		'description' => $this->input->post('description',TRUE),
		'publish_date' => $this->input->post('publish_date',TRUE),
		'expired_date' => $this->input->post('expired_date',TRUE),
	    );
            //print_r($_FILES['image']['name']);
            $this->load->library('upload');
            $path = base_url().'uploads';

            $config = array();
            $config['upload_path'] = '/opt/lampp/htdocs/CI-crude/uploads';
            //$config['upload_path'] = $this->config->item('base_path') . 'uploads';  // Dynamic 
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size'] = '11110000';           // Always check upload image size
            $config['max_width'] = '0';
            $config['max_height'] = '0';
            
            $this->upload->initialize($config);

            if ($this->upload->do_upload('image')){
                $data1['image'] = $this->upload->data();
                $data['image'] = $data1['image']['file_name'];
            }else {
                $data['image']= '';
            }
            
            $this->News_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('news'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->News_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('news/update_action'),
		'news_id' => set_value('news_id', $row->news_id),
		'title' => set_value('title', $row->title),
		'summery' => set_value('summery', $row->summery),
		'description' => set_value('description', $row->description),
		'image' => set_value('image', $row->image),
		'publish_date' => set_value('publish_date', $row->publish_date),
		'expired_date' => set_value('expired_date', $row->expired_date),
	    );
            $this->load->view('news/news_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('news'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('news_id', TRUE));
        } else {
            $data = array(
		'title' => $this->input->post('title',TRUE),
		'summery' => $this->input->post('summery',TRUE),
		'description' => $this->input->post('description',TRUE),
		'image' => $this->input->post('image',TRUE),
		'publish_date' => $this->input->post('publish_date',TRUE),
		'expired_date' => $this->input->post('expired_date',TRUE),
	    );

            $this->News_model->update($this->input->post('news_id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('news'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->News_model->get_by_id($id);

        if ($row) {
            $this->News_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('news'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('news'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('title', 'title', 'trim|required');
	$this->form_validation->set_rules('summery', 'summery', 'trim|required');
	$this->form_validation->set_rules('description', 'description', 'trim|required');
	// $this->form_validation->set_rules('image', 'image', 'trim|required');
	$this->form_validation->set_rules('publish_date', 'publish date', 'trim|required');
	$this->form_validation->set_rules('expired_date', 'expired date', 'trim|required');

	$this->form_validation->set_rules('news_id', 'news_id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "news.xls";
        $judul = "news";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Title");
	xlsWriteLabel($tablehead, $kolomhead++, "Summery");
	xlsWriteLabel($tablehead, $kolomhead++, "Description");
	xlsWriteLabel($tablehead, $kolomhead++, "Image");
	xlsWriteLabel($tablehead, $kolomhead++, "Publish Date");
	xlsWriteLabel($tablehead, $kolomhead++, "Expired Date");

	foreach ($this->News_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->title);
	    xlsWriteLabel($tablebody, $kolombody++, $data->summery);
	    xlsWriteLabel($tablebody, $kolombody++, $data->description);
	    xlsWriteLabel($tablebody, $kolombody++, $data->image);
	    xlsWriteLabel($tablebody, $kolombody++, $data->publish_date);
	    xlsWriteLabel($tablebody, $kolombody++, $data->expired_date);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

}

