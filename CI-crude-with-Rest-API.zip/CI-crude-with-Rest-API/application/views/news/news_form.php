<!doctype html>
<html>
    <head>
        <title>codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">News <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post" enctype="multipart/form-data">
	    <div class="form-group">
            <label for="varchar">Title <?php echo form_error('title') ?></label>
            <input type="text" class="form-control" name="title" id="title" placeholder="Title" value="<?php echo $title; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Summery <?php echo form_error('summery') ?></label>
            <input type="text" class="form-control" name="summery" id="summery" placeholder="Summery" value="<?php echo $summery; ?>" />
        </div>
	    <div class="form-group">
            <label for="description">Description <?php echo form_error('description') ?></label>
            <textarea class="form-control" rows="3" name="description" id="description" placeholder="Description"><?php echo $description; ?></textarea>
        </div>
	    <div class="form-group">
            <label for="varchar">Image <?php echo form_error('image') ?></label>
            <!-- <input type="text" class="form-control" name="image" id="image" placeholder="Image" value="<?php //echo $image; ?>" /> -->
            <input type="file" class="form-control" name="image" id="image" placeholder="Image" value="<?php echo $image; ?>" />
        </div>
	    <div class="form-group">
            <label for="date">Publish Date <?php echo form_error('publish_date') ?></label>
            <input type="date" class="form-control" name="publish_date" id="publish_date" placeholder="Publish Date" value="<?php echo $publish_date; ?>" />
        </div>
	    <div class="form-group">
            <label for="date">Expired Date <?php echo form_error('expired_date') ?></label>
            <input type="date" class="form-control" name="expired_date" id="expired_date" placeholder="Expired Date" value="<?php echo $expired_date; ?>" />
        </div>
	    <input type="hidden" name="news_id" value="<?php echo $news_id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('news') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>