<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class NestedCategory extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('NestedCategory_Model');
    }
    
    

    public function index() {
        $result = $this->NestedCategory_Model->get_All();
        $data = array(
            'view' => 'category_list',
            'result_list' => $result,
        );
        $this->load->view('content',$data);
    }
    
    public function delete(){
        $id = $this->uri->segment(3);
        $this->NestedCategory_Model->delete_Category($id);
        redirect('NestedCategory');
    }

}
