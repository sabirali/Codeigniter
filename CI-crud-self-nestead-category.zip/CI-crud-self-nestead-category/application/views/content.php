<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Codeigniter CRUD Operation of Nested Category By Sabirali Kharodiya</title>
        <?php $this->load->view('template/head'); ?>
    </head>
    <body>
        <div class="container">
            <?php $this->load->view('template/header'); ?>
        </div>
        <?php $this->load->view($view); ?>
    </body>
</html>
