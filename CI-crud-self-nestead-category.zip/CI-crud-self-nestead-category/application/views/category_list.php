<div class="container">
    <div class="row">
        <table class="table">
            <thead>
                <tr>
                    <th>Sr.No</th>
                    <th>Category Name</th>
                    <th>Parent ID</th>
                    <th>Parent Name</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($result_list as $row) { ?>
                    <tr>
                        <td><?php echo $row->id ?></td>
                        <td><?php echo $row->category ?></td>
                        <td><?php echo $row->relation ?></td>
                        <td><?php echo $row->parent_name ?></td>
                        <td style="text-align:center" width="238px">
                            <?php
                            echo anchor(site_url('NestedCategory/read' . $row->id), '<button type="button" class="btn btn-info btn-xs"><i class="fa fa-book mr5"></i>View</button>');
                            echo ' | ';
                            echo anchor(site_url('NestedCategory/update' . $row->id), '<button type="button" class="btn btn-primary btn-xs"><i class="fa fa-pencil mr5"></i>Edit</button>');
                            echo ' | ';
                            echo anchor(site_url('NestedCategory/delete/' . $row->id) , '<button type="button" class="btn btn-danger btn-xs"><i class="fa fa-trash-o mr5"></i>Delete</button>', 'onclick="javasciprt: return confirm(\'Are You Sure want to delete this ?\')"');
                            ?>
                        </td>
                    </tr>      
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>
