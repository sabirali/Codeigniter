<?php

class NestedCategory_Model extends CI_Model {

    private $table = 'nested_category';

    /**
     * 
     *  Get categories using JOIN OR Recursively Start
     */
    public function get_All() {
        // Using Join
        $qry = $this->db->select("c1.id,c1.category,c1.relation,c2.category as parent_name")
                ->join('nested_category as c2', "c1.relation = c2.id", "left")
                ->order_by('c1.id', 'ASC')
                ->get('nested_category as c1');
        return $qry->result();
    }
    // Using recursively function 
    public function get_categories() {

        $this->db->select('*');
        $this->db->from('nested_category');
        $this->db->where('relation', 0);
        $categories = $this->db->get()->result();
        $i = 0;
        foreach ($categories as $p_cat) {
            if (isset($p_cat->id)) {
                $categories[$i]->sub = $this->sub_categories($p_cat->id);
                $i++;
            }
        }
        return $categories;
    }

    public function sub_categories($id) {

        $this->db->select('*');
        $this->db->from('nested_category');
        $this->db->where('relation', $id);

        $child = $this->db->get();
        $categories = $child->result_array();
        $categories_string = implode(',', array_column($categories, 'category'));
        $i = 0;
        foreach ($categories as $p_cat) {
            $categories_string[$i]->sub = $this->sub_categories($p_cat->id);
            $i++;
        }
        return $categories_string;
    }

    /**
     *  End
     */

    /**
     * 
     *  To delete nested categories foreign key OR Recursively start
     */
    public function delete_Category($id) {
        // With foreign key on same table
        //ALTER TABLE `nested`.`nested_category` ADD FOREIGN KEY (`pid`) REFERENCES `nested`.`nested_category`(`id`) ON UPDATE CASCADE ON DELETE CASCADE;
        $qry = $this->db->where("id", $id)
                ->delete("nested_category");

        // Without foreign key using Recursively
        /* $this->db->delete('nested_category', ['id' => $id]);
          //fetch child categories & call the same method again.
          $q = $this->db->where('relation', $id)->get('nested_category');
          foreach ($q->result() as $Child) {
          $this->delete_Category($Child->id);
          } */
    }

    /**
     *  End
     */
}
