-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 03, 2019 at 12:28 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 5.6.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `CI-crud-self-nestead-category`
--

-- --------------------------------------------------------

--
-- Table structure for table `nested_category`
--

CREATE TABLE `nested_category` (
  `id` int(15) NOT NULL,
  `category` varchar(150) NOT NULL,
  `relation` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nested_category`
--

INSERT INTO `nested_category` (`id`, `category`, `relation`) VALUES
(1, 'Home', NULL),
(2, 'Tutorials', NULL),
(10, 'webservices', NULL),
(11, 'REST', 10),
(12, 'SOAP', 10),
(13, 'Contact', NULL),
(14, 'About', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `nested_category`
--
ALTER TABLE `nested_category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `_idx` (`relation`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `nested_category`
--
ALTER TABLE `nested_category`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `nested_category`
--
ALTER TABLE `nested_category`
  ADD CONSTRAINT `nested_category_ibfk_1` FOREIGN KEY (`relation`) REFERENCES `nested_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
